export interface error {
  error: string;
}
