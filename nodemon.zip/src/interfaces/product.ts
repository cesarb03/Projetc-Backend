export interface product {
  name: string;
  price: number;
  photoURL: string;
}
